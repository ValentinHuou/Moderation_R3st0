package utilitaire.crypto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CryptoTest {
    
    public CryptoTest() {
    }
    
    @BeforeEach
    public void setUp() {
        // Initialisation si nécessaire
    }

    /**
     * Test de la méthode chiffrer.
     * On vérifie que le résultat n'est pas vide et qu'il diffère de l'original.
     */
    @Test
    public void testChiffrer() {
        String texteOriginal = "MdpModo123!";
        String resultat = Crypto.chiffrer(texteOriginal);
        
        assertNotNull(resultat, "Le résultat du chiffrement ne doit pas être nul.");
        assertNotEquals(texteOriginal, resultat, "Le texte chiffré doit être différent du texte original.");
        System.out.println(resultat);
    }

    /**
     * Test de la méthode dechiffrer.
     * On vérifie qu'un cycle complet (chiffrer puis déchiffrer) redonne le texte initial.
     */
    @Test
    public void testDechiffrer() {
        String texteOriginal = "Donnée de test 123";
        
        String texteChiffre = Crypto.chiffrer(texteOriginal);
        
        String resultatDechiffre = Crypto.dechiffrer(texteChiffre);
        
        assertEquals(texteOriginal, resultatDechiffre, "Le déchiffrement doit restituer exactement le texte original.");
    }
}