package e6_r3st0_moderation;

import vues.LoginView;

import javax.swing.*;

/**
 * Point d'entrée de l'application de modération des avis.
 *
 * Prérequis :
 *  1. MySQL en écoute sur localhost:3308  (modifiez ConnexionBDD si besoin)
 *  2. Avoir exécuté sql/update_bdd.sql sur la base resto2
 *  3. mysql-connector-j.jar dans le classpath
 *     (optionnel) jbcrypt.jar si les mots de passe sont hashés en BCrypt
 *
 * Compilation (depuis le dossier src/) :
 *   javac -cp .;mysql-connector-j.jar connexion/*.java modele/*.java dao/*.java vue/*.java Main.java
 *
 * Lancement :
 *   java  -cp .;mysql-connector-j.jar Main
 */
public class main {

    public static void main(String[] args) {
        // Apparence système
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> new LoginView().setVisible(true));
    }
}
