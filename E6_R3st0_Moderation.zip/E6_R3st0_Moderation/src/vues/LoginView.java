package vues;

import modele.dao.UtilisateurDAO;
import modele.metier.Utilisateur;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

/**
 * Fenêtre de connexion pour accéder à l'espace de modération.
 */
public class LoginView extends JFrame {

    private JTextField      champMail;
    private JPasswordField  champMdp;
    private JLabel          lblErreur;

    public LoginView() {
        super("Connexion – Espace modération");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setSize(420, 280);
        setLocationRelativeTo(null);
        construireUI();
    }

    private void construireUI() {
        JPanel principal = new JPanel(new BorderLayout(0, 0));
        principal.setBackground(Color.WHITE);

        // ── Titre ────────────────────────────────────────────────────────────
        JPanel panTitre = new JPanel();
        panTitre.setBackground(new Color(245, 245, 245));
        panTitre.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(210, 210, 210)),
                new EmptyBorder(14, 20, 14, 20)));
        JLabel lblTitre = new JLabel("Gestionnaire des avis – Espace modération");
        lblTitre.setFont(new Font("Arial", Font.PLAIN, 16));
        panTitre.add(lblTitre);

        // ── Formulaire ────────────────────────────────────────────────────────
        JPanel panForm = new JPanel(new GridBagLayout());
        panForm.setBackground(Color.WHITE);
        panForm.setBorder(new EmptyBorder(18, 30, 10, 30));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.anchor = GridBagConstraints.WEST;

        g.gridx = 0; g.gridy = 0;
        panForm.add(new JLabel("Adresse e-mail :"), g);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        champMail = new JTextField(18);
        panForm.add(champMail, g);

        g.gridx = 0; g.gridy = 1; g.fill = GridBagConstraints.NONE; g.weightx = 0;
        panForm.add(new JLabel("Mot de passe :"), g);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        champMdp = new JPasswordField(18);
        panForm.add(champMdp, g);

        lblErreur = new JLabel(" ");
        lblErreur.setForeground(new Color(180, 30, 30));
        lblErreur.setFont(new Font("Arial", Font.ITALIC, 11));
        g.gridx = 0; g.gridy = 2; g.gridwidth = 2;
        g.fill = GridBagConstraints.HORIZONTAL;
        panForm.add(lblErreur, g);

        // ── Boutons ───────────────────────────────────────────────────────────
        JPanel panBoutons = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        panBoutons.setBackground(Color.WHITE);

        JButton btnConnexion = new JButton("Se connecter");
        JButton btnAnnuler   = new JButton("Annuler");

        btnConnexion.setPreferredSize(new Dimension(130, 30));
        btnAnnuler  .setPreferredSize(new Dimension(100, 30));

        btnConnexion.addActionListener(e -> tentativeConnexion());
        btnAnnuler  .addActionListener(e -> System.exit(0));

        // Connexion avec Entrée depuis les champs
        ActionListener entree = e -> tentativeConnexion();
        champMail.addActionListener(entree);
        champMdp .addActionListener(entree);

        panBoutons.add(btnConnexion);
        panBoutons.add(btnAnnuler);

        principal.add(panTitre,   BorderLayout.NORTH);
        principal.add(panForm,    BorderLayout.CENTER);
        principal.add(panBoutons, BorderLayout.SOUTH);

        setContentPane(principal);
    }

    private void tentativeConnexion() {
        String mail = champMail.getText().trim();
        String mdp  = new String(champMdp.getPassword());

        if (mail.isEmpty() || mdp.isEmpty()) {
            lblErreur.setText("Veuillez remplir tous les champs.");
            return;
        }

        try {
            UtilisateurDAO dao = new UtilisateurDAO();
            Utilisateur u = dao.authentifier(mail, mdp);

            if (u == null) {
                lblErreur.setText("Identifiants incorrects ou accès non autorisé.");
                champMdp.setText("");
            } else {
                dispose();
                SwingUtilities.invokeLater(() ->
                        new ModerationListeView(u).setVisible(true));
            }
        } catch (Exception ex) {
            lblErreur.setText("Erreur de connexion : " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
