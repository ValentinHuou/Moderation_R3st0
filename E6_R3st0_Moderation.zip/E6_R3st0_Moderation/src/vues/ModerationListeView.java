package vues;

import controller.CommentaireController;
import modele.metier.Commentaire;
import modele.metier.Role;
import modele.metier.StatutCommentaire;
import modele.metier.Utilisateur;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Vue principale de l'espace de modération.
 * Affiche la liste des avis avec filtres et actions.
 * Délègue toute la logique métier à CommentaireController.
 *
 * Rôles :
 *  - MODERATEUR → Voir détail | Masquer | Quitter
 *  - ADMIN      → Voir détail | Masquer | Archiver | Rétablir | Supprimer | Quitter
 */
public class ModerationListeView extends JFrame {

    // ── Dépendances ───────────────────────────────────────────────────────────
    private final Utilisateur            utilisateur;
    private final CommentaireController  controller = new CommentaireController();

    // ── Filtres ───────────────────────────────────────────────────────────────
    private JTextField              champDate;
    private JComboBox<String>       comboStatut;

    // ── Tableau ───────────────────────────────────────────────────────────────
    private JTable                  tableau;
    private DefaultTableModel       modeleTableau;
    private List<Commentaire>       commentairesAffiches;

    private static final String[]   COLONNES = {"UTILISATEUR", "DATE", "COMMENTAIRE", "RESTAURANT", "NOTE", "RAISON MASQUAGE"};
    private static final DateTimeFormatter FMT_AFFICHAGE = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter FMT_SAISIE    = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // ── Constructeur ──────────────────────────────────────────────────────────
    public ModerationListeView(Utilisateur utilisateur) {
        super("Gestionnaire des avis – Espace modération");
        this.utilisateur = utilisateur;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(870, 580);
        setLocationRelativeTo(null);
        construireUI();
        chargerDonnees();
    }

    // ── Construction de l'interface ───────────────────────────────────────────
    private void construireUI() {
        JPanel principal = new JPanel(new BorderLayout(0, 8));
        principal.setBackground(Color.WHITE);
        principal.setBorder(new EmptyBorder(0, 0, 0, 0));

        principal.add(creerPanelTitre(),   BorderLayout.NORTH);
        principal.add(creerPanelCentre(),  BorderLayout.CENTER);
        principal.add(creerPanelBoutons(), BorderLayout.SOUTH);

        setContentPane(principal);
    }

    // ── Titre ─────────────────────────────────────────────────────────────────
    private JPanel creerPanelTitre() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);

        JLabel lbl = new JLabel("Gestionnaire des avis - Espace modération", SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.PLAIN, 22));
        lbl.setBorder(new EmptyBorder(16, 10, 8, 10));
        p.add(lbl, BorderLayout.CENTER);
        return p;
    }

    // ── Filtres + tableau ─────────────────────────────────────────────────────
    private JPanel creerPanelCentre() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(0, 16, 0, 16));

        p.add(creerPanelFiltres(), BorderLayout.NORTH);

        modeleTableau = new DefaultTableModel(COLONNES, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tableau = new JTable(modeleTableau);
        tableau.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableau.setRowHeight(28);
        tableau.setFont(new Font("Arial", Font.PLAIN, 13));
        tableau.setGridColor(new Color(210, 210, 210));
        tableau.setShowHorizontalLines(true);
        tableau.setShowVerticalLines(true);
        tableau.setIntercellSpacing(new Dimension(0, 0));

        tableau.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tableau.getTableHeader().setBackground(new Color(220, 220, 220));
        tableau.getTableHeader().setReorderingAllowed(false);

        // Désactive le redimensionnement automatique pour activer le scroll horizontal
        tableau.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int[] largeurs = {75, 135, 240, 130, 50, 200};
        for (int i = 0; i < largeurs.length; i++)
            tableau.getColumnModel().getColumn(i).setPreferredWidth(largeurs[i]);

        DefaultTableCellRenderer centreur = new DefaultTableCellRenderer();
        centreur.setHorizontalAlignment(SwingConstants.CENTER);
        tableau.getColumnModel().getColumn(1).setCellRenderer(centreur);
        tableau.getColumnModel().getColumn(4).setCellRenderer(centreur);

        // Colonne RAISON MASQUAGE : texte tronqué avec tooltip sur le texte complet
        tableau.getColumnModel().getColumn(5).setCellRenderer(
                new javax.swing.table.DefaultTableCellRenderer() {
                    @Override
                    public java.awt.Component getTableCellRendererComponent(
                            JTable t, Object value, boolean sel, boolean focus, int row, int col) {
                        super.getTableCellRendererComponent(t, value, sel, focus, row, col);
                        String texte = value != null ? value.toString() : "";
                        setToolTipText(texte.isEmpty() ? null : texte);
                        setForeground(sel ? t.getSelectionForeground() : new Color(130, 60, 0));
                        return this;
                    }
                });

        tableau.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) voirDetail();
            }
        });

        JScrollPane scroll = new JScrollPane(tableau,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(190, 190, 190)));
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    private JPanel creerPanelFiltres() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setBackground(Color.WHITE);

        champDate = new JTextField(FMT_SAISIE.format(LocalDate.now()), 10);
        champDate.setFont(new Font("Arial", Font.PLAIN, 13));
        champDate.setToolTipText("Format : dd/MM/yyyy  — Laisser vide pour ignorer le filtre de date");

        JPanel panDate = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
        panDate.setBorder(BorderFactory.createLineBorder(new Color(170, 170, 170)));
        panDate.setBackground(Color.WHITE);
        panDate.add(champDate);
        JLabel ico = new JLabel("📅");
        ico.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        ico.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { champDate.setText(""); chargerDonnees(); }
        });
        ico.setToolTipText("Effacer la date");
        panDate.add(ico);

        String[] options = {"Tous", "Actifs", "Masqués", "Archivés"};
        comboStatut = new JComboBox<>(options);
        comboStatut.setFont(new Font("Arial", Font.PLAIN, 13));
        comboStatut.setPreferredSize(new Dimension(130, 30));

        JButton btnActualiser = new JButton("Actualiser");
        btnActualiser.setFont(new Font("Arial", Font.PLAIN, 13));
        btnActualiser.addActionListener(e -> chargerDonnees());

        p.add(panDate);
        p.add(comboStatut);
        p.add(btnActualiser);

        JLabel lblRole = new JLabel(utilisateur.getPseudoU() + " · " + utilisateur.getRole());
        lblRole.setFont(new Font("Arial", Font.ITALIC, 11));
        lblRole.setForeground(Color.GRAY);
        JPanel pRight = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pRight.setBackground(Color.WHITE);
        pRight.add(lblRole);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(Color.WHITE);
        wrapper.add(p, BorderLayout.WEST);
        wrapper.add(pRight, BorderLayout.EAST);
        return wrapper;
    }

    // ── Boutons du bas ────────────────────────────────────────────────────────
    private JPanel creerPanelBoutons() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(210, 210, 210)),
                new EmptyBorder(4, 10, 4, 10)));

        JButton btnDetail  = bouton("Voir détail", e -> voirDetail());
        JButton btnMasquer = bouton("Masquer",     e -> masquerSelectionne());
        JButton btnQuitter = bouton("Quitter",     e -> System.exit(0));

        p.add(btnDetail);
        p.add(btnMasquer);

        if (utilisateur.getRole() == Role.ADMIN) {
            JButton btnArchiver  = bouton("Archiver",  e -> changerStatutSelectionne(StatutCommentaire.ARCHIVE, "archivé"));
            JButton btnRetablir  = bouton("Rétablir",  e -> changerStatutSelectionne(StatutCommentaire.ACTIF,   "rétabli"));
            JButton btnSupprimer = bouton("Supprimer", e -> supprimerSelectionne());
            btnSupprimer.setForeground(new Color(160, 30, 30));
            p.add(btnArchiver);
            p.add(btnRetablir);
            p.add(btnSupprimer);
        }

        p.add(btnQuitter);
        return p;
    }

    // ── Chargement des données ────────────────────────────────────────────────
    /** Recharge le tableau selon les filtres courants. Appelé aussi depuis ModerationDetailView. */
    public void chargerDonnees() {
        modeleTableau.setRowCount(0);
        try {
            StatutCommentaire statut = toStatut((String) comboStatut.getSelectedItem());
            LocalDate date = parseDate(champDate.getText().trim());

            commentairesAffiches = controller.chargerCommentaires(statut, date);

            for (Commentaire c : commentairesAffiches) {
                modeleTableau.addRow(new Object[]{
                        c.getPseudoU(),
                        c.getDateFormatee(),
                        c.getTexte(),
                        c.getNomRestaurant(),
                        c.getNoteFormatee(),
                        c.getStatut() == StatutCommentaire.MASQUE ? c.getRaisonMasquage() : ""
                });
            }
        } catch (Exception ex) {
            afficherErreur("Erreur lors du chargement : " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // ── Actions ───────────────────────────────────────────────────────────────
    private void voirDetail() {
        Commentaire c = getSelection();
        if (c != null) new ModerationDetailView(c, utilisateur, this).setVisible(true);
    }

    /** Demande une raison puis masque le commentaire sélectionné. */
    private void masquerSelectionne() {
        Commentaire c = getSelection();
        if (c == null) return;
        String raison = demanderRaisonMasquage();
        if (raison == null) return;
        try {
            controller.masquerAvecRaison(c, raison);
            JOptionPane.showMessageDialog(this, "Commentaire masqué avec succès.");
            chargerDonnees();
        } catch (Exception ex) {
            afficherErreur("Erreur : " + ex.getMessage());
        }
    }

    private void changerStatutSelectionne(StatutCommentaire nouveau, String libelle) {
        Commentaire c = getSelection();
        if (c == null) return;
        try {
            controller.changerStatut(c, nouveau);
            JOptionPane.showMessageDialog(this, "Commentaire " + libelle + " avec succès.");
            chargerDonnees();
        } catch (Exception ex) {
            afficherErreur("Erreur : " + ex.getMessage());
        }
    }

    private void supprimerSelectionne() {
        Commentaire c = getSelection();
        if (c == null) return;
        int rep = JOptionPane.showConfirmDialog(this,
                "Supprimer définitivement ce commentaire ?\n(action irréversible)",
                "Confirmation de suppression",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (rep == JOptionPane.YES_OPTION) {
            try {
                controller.supprimer(c);
                JOptionPane.showMessageDialog(this, "Commentaire supprimé.");
                chargerDonnees();
            } catch (Exception ex) {
                afficherErreur("Erreur : " + ex.getMessage());
            }
        }
    }

    // ── Popup raison de masquage ───────────────────────────────────────────────
    /**
     * Affiche un dialogue demandant la raison du masquage.
     * @return la raison saisie, ou null si l'utilisateur annule
     */
    private String demanderRaisonMasquage() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(Color.WHITE);
        JLabel label = new JLabel("Expliquez la raison du masquage :");
        label.setFont(new Font("Arial", Font.PLAIN, 13));
        JTextArea area = new JTextArea(4, 30);
        area.setFont(new Font("Arial", Font.PLAIN, 13));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210)));
        panel.add(label, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Raison du masquage", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return null;

        String raison = area.getText().trim();
        if (raison.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir une raison.",
                    "Raison requise", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return raison;
    }

    // ── Utilitaires ───────────────────────────────────────────────────────────
    private Commentaire getSelection() {
        int row = tableau.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un commentaire dans le tableau.",
                    "Sélection requise", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }
        return commentairesAffiches.get(row);
    }

    private StatutCommentaire toStatut(String label) {
        switch (label) {
            case "Masqués":  return StatutCommentaire.MASQUE;
            case "Actifs":   return StatutCommentaire.ACTIF;
            case "Archivés": return StatutCommentaire.ARCHIVE;
            default:         return null;
        }
    }

    private LocalDate parseDate(String texte) {
        if (texte == null || texte.isEmpty()) return null;
        try {
            return LocalDate.parse(texte, FMT_SAISIE);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    private JButton bouton(String texte, java.awt.event.ActionListener al) {
        JButton b = new JButton(texte);
        b.setFont(new Font("Arial", Font.PLAIN, 13));
        b.addActionListener(al);
        return b;
    }

    private void afficherErreur(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Erreur", JOptionPane.ERROR_MESSAGE);
    }
}
