package vues;

import controller.CommentaireController;
import modele.metier.Commentaire;
import modele.metier.Role;
import modele.metier.StatutCommentaire;
import modele.metier.Utilisateur;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * Vue de détail d'un commentaire.
 * Délègue toute la logique métier à CommentaireController.
 *
 * Rôles :
 *  - MODERATEUR → Retour | Masquer | Quitter
 *  - ADMIN      → Retour | Masquer | Archiver | Rétablir | Supprimer | Quitter
 */
public class ModerationDetailView extends JFrame {

    private final Commentaire           commentaire;
    private final Utilisateur           utilisateur;
    private final ModerationListeView   parent;
    private final CommentaireController controller = new CommentaireController();

    public ModerationDetailView(Commentaire commentaire, Utilisateur utilisateur,
                                ModerationListeView parent) {
        super("Gestionnaire des avis – Espace modération");
        this.commentaire = commentaire;
        this.utilisateur = utilisateur;
        this.parent      = parent;

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(720, 400);
        setLocationRelativeTo(parent);
        construireUI();
    }

    private void construireUI() {
        JPanel principal = new JPanel(new BorderLayout(0, 0));
        principal.setBackground(Color.WHITE);

        // Contenu enveloppé dans un JScrollPane pour permettre le défilement horizontal
        JScrollPane scrollContenu = new JScrollPane(creerContenu(),
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollContenu.setBorder(BorderFactory.createEmptyBorder());
        scrollContenu.getViewport().setBackground(Color.WHITE);

        principal.add(creerTitre(),   BorderLayout.NORTH);
        principal.add(scrollContenu,  BorderLayout.CENTER);
        principal.add(creerBoutons(), BorderLayout.SOUTH);

        setContentPane(principal);
    }

    // ── Titre ─────────────────────────────────────────────────────────────────
    private JPanel creerTitre() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        JLabel lbl = new JLabel("Gestionnaire des avis - Espace modération", SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.PLAIN, 22));
        lbl.setBorder(new EmptyBorder(16, 10, 8, 10));
        p.add(lbl);
        return p;
    }

    // ── Contenu ───────────────────────────────────────────────────────────────
    private JPanel creerContenu() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(10, 30, 10, 30));

        String texte = commentaire.getTexte() != null ? commentaire.getTexte() : "(aucun commentaire)";
        String note  = commentaire.getNote()  != null ? commentaire.getNote() + "/5" : "—";

        p.add(ligne("Utilisateur :", commentaire.getPseudoU()));
        p.add(ligne("Date :",        commentaire.getDateFormatee()));
        p.add(ligne("Restaurant :",  commentaire.getNomRestaurant()));
        p.add(ligne("Note :",        note));
        p.add(ligne("Statut :",      commentaire.getStatut().toString()));

        // Raison du masquage — affichée uniquement si le commentaire est masqué
        if (commentaire.getStatut() == StatutCommentaire.MASQUE) {
            String raison = commentaire.getRaisonMasquage();
            JPanel panRaison = new JPanel(new BorderLayout());
            panRaison.setBackground(Color.WHITE);
            panRaison.setBorder(new EmptyBorder(4, 0, 4, 0));

            JLabel lblRaisonLib = new JLabel("Raison : ");
            lblRaisonLib.setFont(new Font("Arial", Font.BOLD, 13));
            lblRaisonLib.setForeground(new Color(160, 80, 0));
            lblRaisonLib.setPreferredSize(new Dimension(120, 20));

            JLabel lblRaisonVal = new JLabel(raison != null && !raison.isEmpty() ? raison : "—");
            lblRaisonVal.setFont(new Font("Arial", Font.ITALIC, 13));
            lblRaisonVal.setForeground(new Color(160, 80, 0));

            panRaison.add(lblRaisonLib, BorderLayout.WEST);
            panRaison.add(lblRaisonVal, BorderLayout.CENTER);
            p.add(panRaison);
        }

        JPanel panComm = new JPanel(new BorderLayout());
        panComm.setBackground(Color.WHITE);
        panComm.setBorder(new EmptyBorder(10, 0, 6, 0));
        JLabel lblLibelle = new JLabel("Commentaire :");
        lblLibelle.setFont(new Font("Arial", Font.BOLD, 13));
        lblLibelle.setPreferredSize(new Dimension(120, 20));
        lblLibelle.setVerticalAlignment(SwingConstants.TOP);

        JTextArea areaTexte = new JTextArea(texte);
        areaTexte.setFont(new Font("Arial", Font.PLAIN, 13));
        areaTexte.setLineWrap(true);
        areaTexte.setWrapStyleWord(true);
        areaTexte.setEditable(false);
        areaTexte.setBackground(new Color(248, 248, 248));
        areaTexte.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 210, 210)),
                new EmptyBorder(4, 6, 4, 6)));

        panComm.add(lblLibelle,                BorderLayout.WEST);
        panComm.add(new JScrollPane(areaTexte), BorderLayout.CENTER);
        p.add(panComm);

        return p;
    }

    /** Crée une ligne "libellé : valeur". */
    private JPanel ligne(String libelle, String valeur) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 4));
        p.setBackground(Color.WHITE);
        JLabel lblL = new JLabel(libelle + " ");
        lblL.setFont(new Font("Arial", Font.BOLD, 13));
        lblL.setPreferredSize(new Dimension(120, 20));
        JLabel lblV = new JLabel(valeur != null ? valeur : "—");
        lblV.setFont(new Font("Arial", Font.PLAIN, 13));
        p.add(lblL);
        p.add(lblV);
        return p;
    }

    // ── Boutons ───────────────────────────────────────────────────────────────
    private JPanel creerBoutons() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(210, 210, 210)),
                new EmptyBorder(4, 10, 4, 10)));

        p.add(bouton("Retour",  e -> dispose()));
        p.add(bouton("Masquer", e -> masquerAction()));

        if (utilisateur.getRole() == Role.ADMIN) {
            JButton btnArch = bouton("Archiver",  e -> action(StatutCommentaire.ARCHIVE, "archivé"));
            JButton btnRet  = bouton("Rétablir",  e -> action(StatutCommentaire.ACTIF,   "rétabli"));
            JButton btnSup  = bouton("Supprimer", e -> supprimer());
            btnSup.setForeground(new Color(160, 30, 30));
            p.add(btnArch);
            p.add(btnRet);
            p.add(btnSup);
        }

        p.add(bouton("Quitter", e -> System.exit(0)));
        return p;
    }

    // ── Logique des actions ───────────────────────────────────────────────────

    /** Demande une raison puis masque le commentaire. */
    private void masquerAction() {
        String raison = demanderRaisonMasquage();
        if (raison == null) return;
        try {
            controller.masquerAvecRaison(commentaire, raison);
            JOptionPane.showMessageDialog(this, "Commentaire masqué avec succès.");
            parent.chargerDonnees();
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void action(StatutCommentaire nouveau, String libelle) {
        try {
            controller.changerStatut(commentaire, nouveau);
            JOptionPane.showMessageDialog(this, "Commentaire " + libelle + " avec succès.");
            parent.chargerDonnees();
            dispose();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimer() {
        int rep = JOptionPane.showConfirmDialog(this,
                "Supprimer définitivement ce commentaire ?\n(action irréversible)",
                "Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (rep == JOptionPane.YES_OPTION) {
            try {
                controller.supprimer(commentaire);
                JOptionPane.showMessageDialog(this, "Commentaire supprimé.");
                parent.chargerDonnees();
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage(),
                        "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // ── Popup raison de masquage ───────────────────────────────────────────────
    /**
     * Affiche un dialogue demandant la raison du masquage.
     * @return la raison saisie, ou null si l'utilisateur annule
     */
    private String demanderRaisonMasquage() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setBackground(Color.WHITE);
        JLabel label = new JLabel("Expliquez la raison du masquage :");
        label.setFont(new Font("Arial", Font.PLAIN, 13));
        JTextArea area = new JTextArea(4, 30);
        area.setFont(new Font("Arial", Font.PLAIN, 13));
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210)));
        panel.add(label, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(this, panel,
                "Raison du masquage", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) return null;

        String raison = area.getText().trim();
        if (raison.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir une raison.",
                    "Raison requise", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return raison;
    }

    // ── Utilitaire ────────────────────────────────────────────────────────────
    private JButton bouton(String texte, java.awt.event.ActionListener al) {
        JButton b = new JButton(texte);
        b.setFont(new Font("Arial", Font.PLAIN, 13));
        b.addActionListener(al);
        return b;
    }
}
