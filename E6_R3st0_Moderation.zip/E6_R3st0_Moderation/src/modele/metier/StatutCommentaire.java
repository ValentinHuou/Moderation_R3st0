/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele.metier;

/**
 * Statut d'un commentaire en base de données.
 */
public enum StatutCommentaire {

    ACTIF("actif", "Actif"),
    MASQUE("masque", "Masqué"),
    ARCHIVE("archive", "Archivé");

    private final String valeurBDD;
    private final String libelle;

    StatutCommentaire(String valeurBDD, String libelle) {
        this.valeurBDD = valeurBDD;
        this.libelle   = libelle;
    }

    public String getValeurBDD() { return valeurBDD; }

    /** Libellé affiché dans l'interface. */
    @Override
    public String toString() { return libelle; }

    /** Convertit la valeur SQL en enum (retourne ACTIF par défaut). */
    public static StatutCommentaire fromValeur(String valeur) {
        if (valeur == null) return ACTIF;
        for (StatutCommentaire s : values()) {
            if (s.valeurBDD.equalsIgnoreCase(valeur)) return s;
        }
        return ACTIF;
    }
}

