package modele.metier;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Commentaire {

    private long   idR;
    private long   idU;
    private String pseudoU;
    private String nomRestaurant;
    private String texte;
    private Integer note;
    private LocalDateTime  date;
    private StatutCommentaire statut;
    private String raisonMasquage;

    // ── Constructeur vide ────────────────────────────────────────────────────
    public Commentaire() {}

    // ── Getters / Setters ────────────────────────────────────────────────────
    public long   getIdR()           { return idR; }
    public void   setIdR(long v)     { idR = v; }

    public long   getIdU()           { return idU; }
    public void   setIdU(long v)     { idU = v; }

    public String getPseudoU()             { return pseudoU; }
    public void   setPseudoU(String v)     { pseudoU = v; }

    public String getNomRestaurant()             { return nomRestaurant; }
    public void   setNomRestaurant(String v)     { nomRestaurant = v; }

    public String  getTexte()          { return texte; }
    public void    setTexte(String v)  { texte = v; }

    public Integer getNote()           { return note; }
    public void    setNote(Integer v)  { note = v; }

    public LocalDateTime getDate()            { return date; }
    public void          setDate(LocalDateTime v) { date = v; }

    public StatutCommentaire getStatut()              { return statut; }
    public void              setStatut(StatutCommentaire v) { statut = v; }

    public String getRaisonMasquage()          { return raisonMasquage; }
    public void   setRaisonMasquage(String v)  { raisonMasquage = v; }

    // ── Utilitaire ────────────────────────────────────────────────────────────
    /** Retourne la date formatée pour l'affichage, ou "—" si absente. */
    public String getDateFormatee() {
        if (date == null) return "—";
        return date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }

    /** Retourne la note formatée (ex : "4/5") ou "—" si absente. */
    public String getNoteFormatee() {
        return note != null ? note + "/5" : "—";
    }
}