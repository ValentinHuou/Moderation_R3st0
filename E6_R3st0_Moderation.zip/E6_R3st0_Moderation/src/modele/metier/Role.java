/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele.metier;

/**
 * Rôle d'un utilisateur dans l'application de modération.
 * - MODERATEUR : peut masquer les avis
 * - ADMIN      : restaurateur – peut archiver, rétablir et supprimer
 */
public enum Role {

    UTILISATEUR("utilisateur"),
    MODERATEUR("moderateur"),
    ADMIN("admin");

    private final String valeurBDD;

    Role(String valeurBDD) { this.valeurBDD = valeurBDD; }

    public String getValeurBDD() { return valeurBDD; }

    public static Role fromValeur(String valeur) {
        if (valeur == null) return UTILISATEUR;
        for (Role r : values()) {
            if (r.valeurBDD.equalsIgnoreCase(valeur)) return r;
        }
        return UTILISATEUR;
    }
}
