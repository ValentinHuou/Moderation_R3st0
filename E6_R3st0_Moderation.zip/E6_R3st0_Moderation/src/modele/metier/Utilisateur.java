/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele.metier;

/**
 * Représente un utilisateur authentifié (modérateur ou admin).
 */
public class Utilisateur {

    private long   idU;
    private String mailU;
    private String pseudoU;
    private Role   role;

    public Utilisateur() {}

    public long   getIdU()           { return idU; }
    public void   setIdU(long v)     { idU = v; }

    public String getMailU()             { return mailU; }
    public void   setMailU(String v)     { mailU = v; }

    public String getPseudoU()             { return pseudoU; }
    public void   setPseudoU(String v)     { pseudoU = v; }

    public Role   getRole()          { return role; }
    public void   setRole(Role v)    { role = v; }

    @Override
    public String toString() { return pseudoU + " [" + role + "]"; }
}
