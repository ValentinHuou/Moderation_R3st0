package modele.dao;

import utilitaire.crypto.Crypto;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Connexion à la base de données MySQL (Singleton).
 * Les paramètres sont lus depuis server.properties (à la racine du projet).
 * Le mot de passe est stocké chiffré et déchiffré via Crypto.
 */
public class ConnexionBDD {

    private static ConnexionBDD instance;
    private Connection connection;

    private ConnexionBDD() throws SQLException {
        try {
            Properties props = new Properties();
            FileInputStream in = new FileInputStream("server.properties");
            props.load(in);
            in.close();

            String host     = props.getProperty("db.host");
            String port     = props.getProperty("db.port");
            String dbName   = props.getProperty("db.name");
            String user     = props.getProperty("db.user");
            String password = Crypto.dechiffrer(props.getProperty("db.password"));

            String url = "jdbc:mysql://" + host + ":" + port + "/" + dbName
                    + "?zeroDateTimeBehavior=CONVERT_TO_NULL"
                    + "&serverTimezone=Europe/Paris"
                    + "&useSSL=false"
                    + "&allowPublicKeyRetrieval=true";

            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(url, user, password);

        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver MySQL introuvable. Ajoutez mysql-connector-j.jar au classpath.", e);
        } catch (IOException e) {
            throw new SQLException("Erreur de lecture de server.properties : " + e.getMessage(), e);
        }
    }

    public static ConnexionBDD getInstance() throws SQLException {
        if (instance == null || instance.connection.isClosed()) {
            instance = new ConnexionBDD();
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }

    public void fermer() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }
}