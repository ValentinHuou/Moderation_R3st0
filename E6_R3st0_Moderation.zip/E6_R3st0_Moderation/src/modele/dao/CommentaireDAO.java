package modele.dao;

import modele.metier.Commentaire;
import modele.metier.StatutCommentaire;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CommentaireDAO {

    // ── Requête de base (réutilisée) ──────────────────────────────────────────
    private static final String SELECT_BASE =
        "SELECT c.idR, c.idU, u.pseudoU, r.nomR, " +
        "       c.commentaire, c.note, c.dateCritique, c.statut, c.raison_masquage " +
        "FROM critiquer c " +
        "JOIN utilisateur u ON c.idU = u.idU " +
        "JOIN resto       r ON c.idR = r.idR " +
        "WHERE c.commentaire IS NOT NULL ";

    /** Retourne tous les commentaires non-nuls, triés par date décroissante. */
    public List<Commentaire> getTous() throws SQLException {
        return executer(SELECT_BASE + "ORDER BY c.dateCritique DESC");
    }

    /** Retourne les commentaires filtrés par statut. */
    public List<Commentaire> getParStatut(StatutCommentaire statut) throws SQLException {
        return executer(SELECT_BASE + "AND c.statut = ? ORDER BY c.dateCritique DESC",
                statut.getValeurBDD());
    }

    /** Retourne les commentaires filtrés par statut ET par date (jour précis). */
    public List<Commentaire> getParStatutEtDate(StatutCommentaire statut, LocalDate date)
            throws SQLException {
        return executer(SELECT_BASE +
                "AND c.statut = ? AND DATE(c.dateCritique) = ? ORDER BY c.dateCritique DESC",
                statut.getValeurBDD(), Date.valueOf(date));
    }

    /** Retourne tous les commentaires d'une date précise. */
    public List<Commentaire> getParDate(LocalDate date) throws SQLException {
        return executer(SELECT_BASE +
                "AND DATE(c.dateCritique) = ? ORDER BY c.dateCritique DESC",
                Date.valueOf(date));
    }

    // ── Écriture ──────────────────────────────────────────────────────────────

    /**
     * Masque un commentaire et enregistre la raison fournie par le modérateur.
     * @return true si la mise à jour a touché exactement 1 ligne
     */
    public boolean masquerAvecRaison(long idR, long idU, String raison) throws SQLException {
        String sql = "UPDATE critiquer SET statut = ?, raison_masquage = ? WHERE idR = ? AND idU = ?";
        try (PreparedStatement ps = ConnexionBDD.getInstance().getConnection().prepareStatement(sql)) {
            ps.setString(1, StatutCommentaire.MASQUE.getValeurBDD());
            ps.setString(2, raison);
            ps.setLong(3, idR);
            ps.setLong(4, idU);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Modifie le statut d'un commentaire identifié par (idR, idU).
     * Remet raison_masquage à NULL si le nouveau statut n'est pas MASQUE.
     * @return true si la mise à jour a touché exactement 1 ligne
     */
    public boolean changerStatut(long idR, long idU, StatutCommentaire nouveauStatut)
            throws SQLException {
        String sql = "UPDATE critiquer SET statut = ?, raison_masquage = NULL WHERE idR = ? AND idU = ?";
        try (PreparedStatement ps = ConnexionBDD.getInstance().getConnection().prepareStatement(sql)) {
            ps.setString(1, nouveauStatut.getValeurBDD());
            ps.setLong(2, idR);
            ps.setLong(3, idU);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Supprime définitivement un commentaire.
     * @return true si la suppression a touché exactement 1 ligne
     */
    public boolean supprimer(long idR, long idU) throws SQLException {
        String sql = "DELETE FROM critiquer WHERE idR = ? AND idU = ?";
        try (PreparedStatement ps = ConnexionBDD.getInstance().getConnection().prepareStatement(sql)) {
            ps.setLong(1, idR);
            ps.setLong(2, idU);
            return ps.executeUpdate() > 0;
        }
    }

    /** Exécute une requête SELECT avec 0..N paramètres positionnels. */
    private List<Commentaire> executer(String sql, Object... params) throws SQLException {
        List<Commentaire> liste = new ArrayList<>();
        Connection conn = ConnexionBDD.getInstance().getConnection();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                if (params[i] instanceof String) {
                    ps.setString(i + 1, (String) params[i]);
                } else if (params[i] instanceof Date) {
                    ps.setDate(i + 1, (Date) params[i]);
                } else {
                    ps.setObject(i + 1, params[i]);
                }
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Commentaire c = new Commentaire();
                    c.setIdR(rs.getLong("idR"));
                    c.setIdU(rs.getLong("idU"));
                    c.setPseudoU(rs.getString("pseudoU"));
                    c.setNomRestaurant(rs.getString("nomR"));
                    c.setTexte(rs.getString("commentaire"));

                    Object n = rs.getObject("note");
                    c.setNote(n != null ? ((Number) n).intValue() : null);

                    Timestamp ts = rs.getTimestamp("dateCritique");
                    if (ts != null) c.setDate(ts.toLocalDateTime());

                    c.setStatut(StatutCommentaire.fromValeur(rs.getString("statut")));
                    c.setRaisonMasquage(rs.getString("raison_masquage"));
                    liste.add(c);
                }
            }
        }
        return liste;
    }
}
