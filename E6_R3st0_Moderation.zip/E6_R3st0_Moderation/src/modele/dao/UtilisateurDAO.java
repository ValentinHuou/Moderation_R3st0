/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele.dao;

import modele.dao.ConnexionBDD;
import modele.metier.Role;
import modele.metier.Utilisateur;

import java.sql.*;

/**
 * Accès aux données pour l'authentification.
 *
 * ⚠️  Les mots de passe en base sont hashés avec des algorithmes variés
 *     (MD5-crypt, bcrypt, DES-crypt…). Pour la démo, on compare en clair
 *     OU via BCrypt si la dépendance jBCrypt est disponible.
 *     Adaptez verifierMotDePasse() selon votre stratégie.
 */
public class UtilisateurDAO {

    /**
     * Recherche un utilisateur par mail et vérifie son mot de passe.
     * Retourne null si les identifiants sont incorrects ou si le rôle
     * ne permet pas l'accès à l'espace modération.
     */
    public Utilisateur authentifier(String mail, String motDePasse) throws SQLException {
        String sql = "SELECT idU, mailU, pseudoU, mdpU, roleU " +
                     "FROM utilisateur WHERE mailU = ?";

        Connection conn = ConnexionBDD.getInstance().getConnection();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, mail);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;

                String hashEnBase = rs.getString("mdpU");
                if (!verifierMotDePasse(motDePasse, hashEnBase)) return null;

                Role role = Role.fromValeur(rs.getString("roleU"));
                // Seuls modérateur et admin ont accès à cet espace
                if (role == Role.UTILISATEUR) return null;

                Utilisateur u = new Utilisateur();
                u.setIdU(rs.getLong("idU"));
                u.setMailU(rs.getString("mailU"));
                u.setPseudoU(rs.getString("pseudoU"));
                u.setRole(role);
                return u;
            }
        }
    }

        /**
         * Vérifie le mot de passe.
         * Adapté pour les démos : accepte la comparaison en clair ou BCrypt.
         * Remplacez par votre algorithme réel.
         */
        private boolean verifierMotDePasse(String saisi, String hash) {
        if (hash == null) return false;
        try {
            return org.apache.commons.codec.digest.Crypt.crypt(saisi, hash).equals(hash);
        } catch (Exception e) {
            return false;
        }
    }
}