package controller;

import modele.dao.UtilisateurDAO;
import modele.metier.Utilisateur;

import java.sql.SQLException;

/**
 * Contrôleur de la vue de connexion.
 * Gère la logique d'authentification séparément de la vue.
 */
public class LoginController {

    private final UtilisateurDAO dao = new UtilisateurDAO();

    /**
     * Tente d'authentifier un utilisateur.
     *
     * @param mail       adresse e-mail saisie
     * @param motDePasse mot de passe saisi
     * @return l'utilisateur authentifié, ou null si les identifiants sont invalides
     * @throws IllegalArgumentException si les champs sont vides
     * @throws SQLException             en cas d'erreur BDD
     */
    public Utilisateur authentifier(String mail, String motDePasse)
            throws IllegalArgumentException, SQLException {

        if (mail == null || mail.isEmpty() || motDePasse == null || motDePasse.isEmpty()) {
            throw new IllegalArgumentException("Veuillez remplir tous les champs.");
        }

        return dao.authentifier(mail, motDePasse);
    }
}
