package controller;

import modele.dao.CommentaireDAO;
import modele.metier.Commentaire;
import modele.metier.StatutCommentaire;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Contrôleur pour la gestion des commentaires.
 * Utilisé par ModerationListeView et ModerationDetailView.
 * Centralise toute la logique métier liée aux commentaires.
 */
public class CommentaireController {

    private final CommentaireDAO dao = new CommentaireDAO();

    /**
     * Charge la liste des commentaires selon les filtres fournis.
     *
     * @param statut filtre sur le statut (null = tous)
     * @param date   filtre sur la date (null = toutes dates)
     * @return liste des commentaires correspondant aux critères
     * @throws SQLException en cas d'erreur BDD
     */
    public List<Commentaire> chargerCommentaires(StatutCommentaire statut, LocalDate date)
            throws SQLException {
        if (statut == null && date == null) return dao.getTous();
        if (statut == null)                 return dao.getParDate(date);
        if (date == null)                   return dao.getParStatut(statut);
        return dao.getParStatutEtDate(statut, date);
    }

    /**
     * Masque un commentaire avec une raison obligatoire.
     * Met à jour l'objet en mémoire après succès.
     *
     * @param commentaire le commentaire à masquer
     * @param raison      raison saisie par le modérateur (non vide)
     * @throws SQLException en cas d'erreur BDD
     */
    public void masquerAvecRaison(Commentaire commentaire, String raison) throws SQLException {
        dao.masquerAvecRaison(commentaire.getIdR(), commentaire.getIdU(), raison);
        commentaire.setStatut(StatutCommentaire.MASQUE);
        commentaire.setRaisonMasquage(raison);
    }

    /**
     * Change le statut d'un commentaire (ACTIF ou ARCHIVE uniquement).
     * Met à jour l'objet en mémoire après succès.
     *
     * @param commentaire    le commentaire à modifier
     * @param nouveauStatut  le nouveau statut à appliquer
     * @throws SQLException en cas d'erreur BDD
     */
    public void changerStatut(Commentaire commentaire, StatutCommentaire nouveauStatut)
            throws SQLException {
        dao.changerStatut(commentaire.getIdR(), commentaire.getIdU(), nouveauStatut);
        commentaire.setStatut(nouveauStatut);
        if (nouveauStatut != StatutCommentaire.MASQUE) {
            commentaire.setRaisonMasquage(null);
        }
    }

    /**
     * Supprime définitivement un commentaire de la base de données.
     *
     * @param commentaire le commentaire à supprimer
     * @throws SQLException en cas d'erreur BDD
     */
    public void supprimer(Commentaire commentaire) throws SQLException {
        dao.supprimer(commentaire.getIdR(), commentaire.getIdU());
    }
}
