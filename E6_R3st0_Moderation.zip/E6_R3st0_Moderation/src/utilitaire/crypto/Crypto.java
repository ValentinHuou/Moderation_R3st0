package utilitaire.crypto;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

public class Crypto {

    // La clé doit faire exactement 32 octets pour de l'AES-256
    private static final String CLE_STR = "12345678901234567890123456789012";
    private static final String ALGORITHME = "AES";

    /**
     * Chiffre une chaîne de caractères et retourne le résultat en Base64.
     */
    public static String chiffrer(String donneeAChiffrer) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(CLE_STR.getBytes(StandardCharsets.UTF_8), ALGORITHME);
            Cipher cipher = Cipher.getInstance(ALGORITHME);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            
            byte[] bytesChiffres = cipher.doFinal(donneeAChiffrer.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(bytesChiffres);
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors du chiffrement : " + e.getMessage());
        }
    }

    /**
     * Déchiffre une chaîne encodée en Base64.
     */
    public static String dechiffrer(String donneeChiffree) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(CLE_STR.getBytes(StandardCharsets.UTF_8), ALGORITHME);
            Cipher cipher = Cipher.getInstance(ALGORITHME);
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            
            byte[] bytesDecode = Base64.getDecoder().decode(donneeChiffree);
            byte[] bytesDechiffres = cipher.doFinal(bytesDecode);
            return new String(bytesDechiffres, StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors du déchiffrement : " + e.getMessage());
        }
    }
}